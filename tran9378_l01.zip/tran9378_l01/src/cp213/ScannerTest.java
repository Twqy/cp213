package cp213;

import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * Class to demonstrate the use of Scanner with a keyboard and File objects.
 *
 * @author Ryan Tran
 * @version 2024-09-20
 */
public class ScannerTest {

    private static final boolean True = false;

    /**
     * Count lines in the scanned file.
     *
     * @param source Scanner to process
     * @return number of lines in scanned file
     */
    public static int countLines(final Scanner source) {
	int count = 0;

	while (source.hasNextLine()) {

	    count++;

	    source.nextLine();
	}
	// your code here
	return count;
    }

    /**
     * Count tokens in the scanned object.
     *
     * @param source Scanner to process
     * @return number of tokens in scanned object
     */
    public static int countTokens(final Scanner source) {

	int tokens = 0;

	while (source.hasNext()) {
	    String line = source.next();

	    StringTokenizer counter = new StringTokenizer(line);

	    tokens += counter.countTokens();
	}

	// your code here
	return tokens;
    }

    /**
     * Ask for and total integers from the keyboard.
     *
     * @param source Scanner to process
     * @return total of positive integers entered from keyboard
     */
    public static int readNumbers(final Scanner keyboard) {
	int total = 0;

	while (keyboard.hasNextLine()) {
	    if (keyboard.hasNextInt()) { // Regular expression to check if input is an integer

		total += keyboard.nextInt();
		keyboard.nextLine();
	    }

	    else {
		String line = keyboard.nextLine();

		if (line.equals("q")) {
		    return total;
		}

		System.out.println("'" + line + "' is not an integer or 'q'.");
	    }
	}

	// your code here

	return total;
    }

}
