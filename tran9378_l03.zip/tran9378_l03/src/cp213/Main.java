package cp213;

import java.time.LocalDate;

/**
 * Tests the Student class.
 *
 * @author Ryan Tran tran9378@mylaurier.ca 1690693978
 * @version 2024-02-10
 */
public class Main {

    public static void main(String[] args) {
	final String line = "-".repeat(40);
	int id = 123456;
	String surname = "Brown";
	String forename = "David";
	LocalDate birthDate = LocalDate.parse("1962-10-25");
	Student student = new Student(id, surname, forename, birthDate);
	String s = student.toString();
	System.out.println(s);
	System.out.println("New Student:");
	System.out.println(student);
	System.out.println(line);
	System.out.println("Test Getters");

	// call getters here
	System.out.println("Student ID: " + student.getId());
	System.out.println("Student Surname: " + student.getSurname());
	System.out.println("Student Forename: " + student.getForename());
	System.out.println("Student Birth Date: " + student.getBirthDate());

	System.out.println(line);
	System.out.println("Test Setters");

	// call setters here
	student.setId(654321);
	student.setSurname("Smith");
	student.setForename("John");
	student.setBirthDate(LocalDate.parse("1990-05-15"));

	System.out.println("Updated Student:");
	System.out.println(student);
	System.out.println(line);
	System.out.println("Test compareTo");

	// create new Students - call comparisons here

	Student s1 = new Student(123456, "Brown", "David", LocalDate.parse("1962-10-25"));
	Student s2 = new Student(0, "A", "B", LocalDate.parse("1900-01-01"));
	int result = s1.compareTo(s2);
	System.out.println(result);
    }
}
