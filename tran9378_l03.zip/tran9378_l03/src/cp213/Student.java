package cp213;

import java.time.LocalDate;

/**
 * Student class definition.
 *
 * @author your name here
 * @version 2022-01-17
 */
/**
 * @author Ryan Tran tran9378@mylaurier.ca 1690693978
 * @version 2024-02-10
 * 
 */
/**
 * 
 */
public class Student implements Comparable<Student> {

    // Attributes
    private LocalDate birthDate = null;
    private String forename = "";
    private int id = 0;
    private String surname = "";

    /**
     * Instantiates a Student object.
     *
     * @param id        student ID number
     * @param surname   student surname
     * @param forename  name of forename
     * @param birthDate birthDate in 'YYYY-MM-DD' format
     */
    public Student(int id, String surname, String forename, LocalDate birthDate) {

	// assign attributes here
	this.id = id;
	this.surname = surname;
	this.forename = forename;
	this.birthDate = birthDate;

	return;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString() Creates a formatted string of student data.
     */
    @Override
    public String toString() {
	String string = "";

	// your code here
	string += "Name:      " + this.surname + ", " + this.forename + "\n";
	String id = "ID:        " + this.id;
	String birthDate = "Birthdate: " + this.birthDate;
	string += id + "\n" + birthDate;

	return string;

    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(final Student target) {
	int result = 0;

	if (this.surname.compareTo(target.surname) != 0) {

	    result = this.surname.compareTo(target.surname);
	} else if (this.forename.compareTo(target.forename) != 0) {

	    result = this.forename.compareTo(target.forename);
	} else {
	    result = Integer.compare(this.id, target.id);
	}

	return result;

    }

    // getters and setters defined here
    /**
     * Fetches student Id
     * 
     * @return id
     */
    public int getId() {

	return this.id;
    }

    /**
     * Sets a new Student ID
     * 
     * @param newId
     * @return new student ID
     */
    public int setId(int newId) {
	this.id = newId;

	return this.id;
    }

    /**
     * Fetches student surname
     * 
     * @return
     */
    public String getSurname() {

	return this.surname;

    }

    /**
     * Sets a new student surname
     * 
     * @param newSurname
     * @return new student surname
     */
    public String setSurname(String newSurname) {

	this.surname = newSurname;

	return this.surname;

    }

    /**
     * gets student forename
     * 
     * @return student forename
     */
    public String getForename() {

	return this.forename;
    }

    /**
     * sets new student forename
     * 
     * @param newForename
     * @return new student forename
     */
    public String setForename(String newForename) {

	this.forename = newForename;

	return this.forename;
    }

    /**
     * Gets student birth date
     * 
     * @return student birthdate
     */
    public LocalDate getBirthDate() {

	return this.birthDate;

    }

    /**
     * Sets new student birth date
     * 
     * @param newBirthDate
     * @return student new birth date
     */

    public LocalDate setBirthDate(LocalDate newBirthDate) {

	this.birthDate = newBirthDate;

	return this.birthDate;
    }

}
