package cp213;

import javax.swing.JFrame;

/**
 * Testing simple example of GUI widgets and inner classes.
 *
 * @author Ryan Tran 169069378 tran9378@mylaurier.ca
 * @version 2022-07-09
 */
public class Main {

    /**
     * Test code.
     *
     * @param args Unused.
     */
    public static void main(String[] args) {

	
	final InnerClassPanel view = new InnerClassPanel();

	
	final JFrame f = new JFrame("Inner Class Examples");
	f.setContentPane(view);
	f.setSize(300, 500);
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	f.setVisible(true);
    }
}
